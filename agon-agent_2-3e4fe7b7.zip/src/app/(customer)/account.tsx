export {default} from '../../screens/AccountScreen';
